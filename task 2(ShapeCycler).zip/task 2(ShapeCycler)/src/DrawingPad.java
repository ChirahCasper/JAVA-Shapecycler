import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class DrawingPad {
    private JFrame frame;
    private Canvas canvas;
    private Graphics graphicsContext;
    private List<Shape> shapes;
    private JComboBox<String> fractalTypeCombo;
    private JTextField levelInput, sizeInput, rotationInput;
    private JButton clearButton;

    public DrawingPad(int width, int height) {
        // Initialize the shape list
        shapes = new ArrayList<>();

        // Create the JFrame
        frame = new JFrame("Drawing Pad");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Create the Canvas
        canvas = new Canvas();
        canvas.setSize(width, height);
        canvas.setBackground(Color.WHITE);

        // Create UI components
        JPanel controlPanel = new JPanel();
        controlPanel.setLayout(new GridLayout(5, 2));

        controlPanel.add(new JLabel("Fractal Type:"));
        fractalTypeCombo = new JComboBox<>(new String[]{"Sierpinski Triangle", "Square", "Rectangle", "Polygon"});
        controlPanel.add(fractalTypeCombo);

        controlPanel.add(new JLabel("Levels:"));
        levelInput = new JTextField("3");
        controlPanel.add(levelInput);

        controlPanel.add(new JLabel("Size:"));
        sizeInput = new JTextField("200");
        controlPanel.add(sizeInput);

        controlPanel.add(new JLabel("Rotation (degrees):"));
        rotationInput = new JTextField("0");
        controlPanel.add(rotationInput);

        // Add a button to generate the fractal
        JButton generateButton = new JButton("Generate Fractal");
        generateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                generateFractal();
            }
        });

        controlPanel.add(generateButton);

        // Clear button to erase the canvas
        clearButton = new JButton("Clear Canvas");
        clearButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                erase();
            }
        });
        controlPanel.add(clearButton);

        // Create a JPanel and add the Canvas
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());
        panel.add(canvas, BorderLayout.CENTER);
        panel.add(controlPanel, BorderLayout.WEST);

        // Add the JPanel to the JFrame
        frame.add(panel);

        // Pack the JFrame to fit the Canvas
        frame.pack();

        // Make the JFrame visible
        frame.setVisible(true);
    }

    public Graphics getGraphicsContext() {
        if (graphicsContext != null) {
            return graphicsContext;
        }
        graphicsContext = canvas.getGraphics();
        if (graphicsContext != null) {
            graphicsContext.setColor(Color.BLACK); // Set default drawing color to black
        }
        return graphicsContext;
    }

    public void draw(Shape shape) {
        Graphics g = getGraphicsContext();
        if (g != null) {
            shape.draw(g);
            shapes.add(shape);
        }
    }

    public void erase() {
        Graphics g = getGraphicsContext();
        if (g != null) {
            Color originalColor = g.getColor();
            g.setColor(Color.WHITE);
            g.fillRect(0, 0, canvas.getWidth(), canvas.getHeight());
            g.setColor(originalColor);
        }
        shapes.clear();
    }

    public void generateFractal() {
        // Read user input
        int levels = Integer.parseInt(levelInput.getText());
        int size = Integer.parseInt(sizeInput.getText());
        int rotation = Integer.parseInt(rotationInput.getText());

        // Generate the fractal based on selected type
        if (fractalTypeCombo.getSelectedItem().equals("Sierpinski Triangle")) {
            Point topLeft = new Point(300, 100);
            Point topRight = new Point(500, 100);
            Point bottom = new Point(400, 300);
            drawSierpinski(topLeft, topRight, bottom, levels, rotation);
        } else if (fractalTypeCombo.getSelectedItem().equals("Square")) {
            Point center = new Point(400, 300);
            Square square = new Square(center, size);
            drawFractalSquare(square, levels, rotation);
        } else if (fractalTypeCombo.getSelectedItem().equals("Rectangle")) {
            Point center = new Point(400, 300);
            Rectangle rectangle = new Rectangle(center, size, size / 2);
            drawFractalRectangle(rectangle, levels, rotation);
        } else if (fractalTypeCombo.getSelectedItem().equals("Polygon")) {
            Point center = new Point(400, 300);
            Polygon polygon = new Polygon(center, size, 6); // Default to 6 sides
            drawFractalPolygon(polygon, levels, rotation);
        }
    }

    public void drawFractalSquare(Square square, int levels, int rotation) {
        if (levels == 0) {
            draw(square);
        } else {
            square.rotate(Math.toRadians(rotation)); // Rotate the square before drawing
            draw(square);
            // Subdivide square into smaller squares and draw them recursively
            int newSize = (int) (square.getSize() / 2);
            Square newSquare1 = new Square(square.getCenter(), newSize);
            newSquare1.rotate(Math.toRadians(rotation));
            drawFractalSquare(newSquare1, levels - 1, rotation);

            Square newSquare2 = new Square(new Point(square.getCenter().getX() + newSize, square.getCenter().getY()), newSize);
            newSquare2.rotate(Math.toRadians(rotation));
            drawFractalSquare(newSquare2, levels - 1, rotation);
        }
    }

    public void drawFractalRectangle(Rectangle rectangle, int levels, int rotation) {
        if (levels == 0) {
            draw(rectangle);
        } else {
            rectangle.rotate(Math.toRadians(rotation)); // Rotate the rectangle before drawing
            draw(rectangle);
            // Subdivide rectangle into smaller rectangles and draw them recursively
            int newWidth = (int) (rectangle.getWidth() / 2);
            int newHeight = (int) (rectangle.getHeight() / 2);
            Rectangle newRectangle1 = new Rectangle(rectangle.getCenter(), newWidth, newHeight);
            newRectangle1.rotate(Math.toRadians(rotation));
            drawFractalRectangle(newRectangle1, levels - 1, rotation);

            Rectangle newRectangle2 = new Rectangle(new Point(rectangle.getCenter().getX() + newWidth, rectangle.getCenter().getY()), newWidth, newHeight);
            newRectangle2.rotate(Math.toRadians(rotation));
            drawFractalRectangle(newRectangle2, levels - 1, rotation);
        }
    }

    public void drawFractalPolygon(Polygon polygon, int levels, int rotation) {
        if (levels == 0) {
            draw(polygon);
        } else {
            polygon.rotate(Math.toRadians(rotation)); // Rotate the polygon before drawing
            draw(polygon);
            // Subdivide polygon into smaller polygons and draw them recursively
            int newSize = (int) (polygon.getSize() / 2);
            Polygon newPolygon = new Polygon(polygon.getCenter(), newSize, polygon.getSides());
            newPolygon.rotate(Math.toRadians(rotation));
            drawFractalPolygon(newPolygon, levels - 1, rotation);
        }
    }

    public void drawSierpinski(Point p1, Point p2, Point p3, int level, int rotation) {
        if (level == 0) {
            Triangle triangle = new Triangle(p1, p2, p3);
            draw(triangle);
        } else {
            Point mid1 = midpoint(p1, p2);
            Point mid2 = midpoint(p2, p3);
            Point mid3 = midpoint(p3, p1);
            drawSierpinski(p1, mid1, mid3, level - 1, rotation);
            drawSierpinski(mid1, p2, mid2, level - 1, rotation);
            drawSierpinski(mid3, mid2, p3, level - 1, rotation);
        }
    }

    public Point midpoint(Point p1, Point p2) {
        int x = (int) ((p1.getX() + p2.getX()) / 2);
        int y = (int) ((p1.getY() + p2.getY()) / 2);
        return new Point(x, y);
    }

    // Abstract shape class
    private static abstract class Shape {
        abstract void draw(Graphics g);
        abstract void rotate(double angle);
    }

    private static class Triangle extends Shape {
        private Point p1, p2, p3;

        public Triangle(Point p1, Point p2, Point p3) {
            this.p1 = p1;
            this.p2 = p2;
            this.p3 = p3;
        }

        @Override
        public void draw(Graphics g) {
            int[] xPoints = {(int) p1.getX(), (int) p2.getX(), (int) p3.getX()};
            int[] yPoints = {(int) p1.getY(), (int) p2.getY(), (int) p3.getY()};
            g.setColor(Color.MAGENTA);
            g.fillPolygon(xPoints, yPoints, 3);
            g.setColor(Color.BLACK);
            g.drawPolygon(xPoints, yPoints, 3);
        }

        @Override
        public void rotate(double angle) {
            p1.rotateAbout(p1, angle);
            p2.rotateAbout(p1, angle);
            p3.rotateAbout(p1, angle);
        }
    }

    private static class Square extends Shape {
        private Point center;
        private double size;

        public Square(Point center, double size) {
            this.center = center;
            this.size = size;
        }

        @Override
        public void draw(Graphics g) {
            int x = (int) (center.getX() - size / 2);
            int y = (int) (center.getY() - size / 2);
            int length = (int) size;
            g.setColor(Color.RED);
            g.fillRect(x, y, length, length);
            g.setColor(Color.BLACK);
            g.drawRect(x, y, length, length);
        }

        @Override
        public void rotate(double angle) {
            center.rotateAbout(center, angle);
        }

        public double getSize() {
            return size;
        }

        public Point getCenter() {
            return center;
        }
    }

    private static class Rectangle extends Shape {
        private Point center;
        private double width, height;

        public Rectangle(Point center, double width, double height) {
            this.center = center;
            this.width = width;
            this.height = height;
        }

        @Override
        public void draw(Graphics g) {
            int x = (int) (center.getX() - width / 2);
            int y = (int) (center.getY() - height / 2);
            g.setColor(Color.BLUE);
            g.fillRect(x, y, (int) width, (int) height);
            g.setColor(Color.BLACK);
            g.drawRect(x, y, (int) width, (int) height);
        }

        @Override
        public void rotate(double angle) {
            center.rotateAbout(center, angle);
        }

        public double getWidth() {
            return width;
        }

        public double getHeight() {
            return height;
        }

        public Point getCenter() {
            return center;
        }
    }

    private static class Polygon extends Shape {
        private Point center;
        private double size;
        private int sides;

        public Polygon(Point center, double size, int sides) {
            this.center = center;
            this.size = size;
            this.sides = sides;
        }

        @Override
        public void draw(Graphics g) {
            int[] xPoints = new int[sides];
            int[] yPoints = new int[sides];
            double angle = 2 * Math.PI / sides;
            for (int i = 0; i < sides; i++) {
                xPoints[i] = (int) (center.getX() + size * Math.cos(i * angle));
                yPoints[i] = (int) (center.getY() + size * Math.sin(i * angle));
            }
            g.setColor(Color.GREEN);
            g.fillPolygon(xPoints, yPoints, sides);
            g.setColor(Color.BLACK);
            g.drawPolygon(xPoints, yPoints, sides);
        }

        @Override
        public void rotate(double angle) {
            center.rotateAbout(center, angle);
        }

        public double getSize() {
            return size;
        }

        public Point getCenter() {
            return center;
        }

        public int getSides() {
            return sides;
        }
    }

    private static class Point {
        private double x, y;

        public Point(double x, double y) {
            this.x = x;
            this.y = y;
        }

        public double getX() {
            return x;
        }

        public double getY() {
            return y;
        }

        public void rotateAbout(Point center, double angle) {
            double cosTheta = Math.cos(angle);
            double sinTheta = Math.sin(angle);

            double newX = center.getX() + (x - center.getX()) * cosTheta - (y - center.getY()) * sinTheta;
            double newY = center.getY() + (x - center.getX()) * sinTheta + (y - center.getY()) * cosTheta;

            x = newX;
            y = newY;
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new DrawingPad(800, 600);
            }
        });
    }
}
