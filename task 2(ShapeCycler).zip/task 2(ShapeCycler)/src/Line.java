import java.util.ArrayList;

// Line.java
public class Line extends Shape {
    private Point start, end;

    // Constructor to initialize the line with two endpoints
    public Line(Point start, Point end) {
        this.start = start;
        this.end = end;
    }

    // Alternate constructor to create a line from 4 coordinates
    public Line(double x1, double y1, double x2, double y2) {
        this.start = new Point(x1, y1);
        this.end = new Point(x2, y2);
    }

    // Getter for the first endpoint
    public Point getFirstPoint() {
        return start;
    }

    // Getter for the second endpoint
    public Point getSecondPoint() {
        return end;
    }

    // Setter for the first endpoint
    public void setFirstPoint(Point p) {
        this.start = p;
    }

    // Setter for the second endpoint
    public void setSecondPoint(Point p) {
        this.end = p;
    }

    /**
     * Returns an ArrayList containing all the points in the line (start and end).
     */
    @Override
    public ArrayList<Point> getPoints() {
        ArrayList<Point> points = new ArrayList<>();
        points.add(start);
        points.add(end);
        return points;
    }

    /**
     * Returns an ArrayList containing this line as the only element.
     */
    @Override
    public ArrayList<Line> getLines() {
        ArrayList<Line> lines = new ArrayList<>();
        lines.add(this);
        return lines;
    }

    /**
     * Computes and returns the center (midpoint) of the line.
     */
    @Override
    public Point getCenter() {
        return new Point(
            (start.getX() + end.getX()) / 2,
            (start.getY() + end.getY()) / 2
        );
    }

    /**
     * Moves the line such that its center is at the given new center.
     */
    @Override
    public void setCenter(Point newCenter) {
        Point currentCenter = getCenter();
        double dx = newCenter.getX() - currentCenter.getX();
        double dy = newCenter.getY() - currentCenter.getY();

        start.setX(start.getX() + dx);
        start.setY(start.getY() + dy);
        end.setX(end.getX() + dx);
        end.setY(end.getY() + dy);
    }

    /**
     * Rotates the line about its center by the specified angle (in degrees).
     */
    @Override
    public void rotate(double angle) {
        Point center = getCenter();
        start.rotateAbout(center, angle);
        end.rotateAbout(center, angle);
    }
}
