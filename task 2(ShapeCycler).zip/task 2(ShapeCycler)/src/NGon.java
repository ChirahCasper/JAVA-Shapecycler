import java.util.ArrayList;

public class NGon extends Polygon {
    private Point center;
    private int sides;
    private double sideLength;

    public NGon(Point center, int sides, double sideLength) {
        super(generatePoints(center, sides, sideLength));
        this.center = center;
        this.sides = sides;
        this.sideLength = sideLength;
    }

    // Method to generate points for an N-sided polygon (NGon)
    private static Point[] generatePoints(Point center, int sides, double sideLength) {
        Point[] points = new Point[sides];
        double angleStep = 2 * Math.PI / sides;
        for (int i = 0; i < sides; i++) {
            double angle = i * angleStep;
            double x = center.getX() + sideLength * Math.cos(angle);
            double y = center.getY() + sideLength * Math.sin(angle);
            points[i] = new Point(x, y);
        }
        return points;
    }

    @Override
    public Point getCenter() {
        return this.center;
    }

    @Override
    public void setCenter(Point newCenter) {
        double dx = newCenter.getX() - this.center.getX();
        double dy = newCenter.getY() - this.center.getY();
        for (Point vertex : vertices) {
            vertex.setX(vertex.getX() + dx);
            vertex.setY(vertex.getY() + dy);
        }
        this.center = newCenter;
    }

    @Override
    public void rotate(double angle) {
        for (Point vertex : vertices) {
            vertex.rotateAbout(center, angle);
        }
    }
}
