// Point.java
public class Point {
    private double x, y;

    // Constructor to initialize the point
    public Point(double x, double y) {
        this.x = x;
        this.y = y;
    }

    // Getter for x-coordinate
    public double getX() {
        return x;
    }

    // Getter for y-coordinate
    public double getY() {
        return y;
    }

    // Setter for x-coordinate
    public void setX(double x) {
        this.x = x;
    }

    // Setter for y-coordinate
    public void setY(double y) {
        this.y = y;
    }

    /**
     * Rotates this point about a given center point by the specified angle.
     * The angle is expected to be in degrees.
     */
    public void rotateAbout(Point center, double angle) {
        // Convert angle to radians
        double radians = Math.toRadians(angle);

        // Translate this point to make 'center' the origin
        double dx = x - center.getX();
        double dy = y - center.getY();

        // Perform rotation
        double rotatedX = dx * Math.cos(radians) - dy * Math.sin(radians);
        double rotatedY = dx * Math.sin(radians) + dy * Math.cos(radians);

        // Translate back to the original coordinate system
        x = center.getX() + rotatedX;
        y = center.getY() + rotatedY;
    }

    /**
     * Compares this point with another for equality, considering floating-point precision.
     */
    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof Point)) return false;
        Point other = (Point) obj;
        return Math.abs(this.x - other.x) < 1e-6 && Math.abs(this.y - other.y) < 1e-6;
    }
}
