import java.util.ArrayList;

public class Polygon extends Shape {
    protected Point[] vertices;

    public Polygon(Point[] vertices) {
        if (vertices.length < 3) {
            throw new IllegalArgumentException("A polygon must have at least 3 points.");
        }
        this.vertices = vertices;
    }

    @Override
    public ArrayList<Point> getPoints() {
        ArrayList<Point> points = new ArrayList<>();
        for (Point vertex : vertices) {
            points.add(vertex);
        }
        return points;
    }

    @Override
    public ArrayList<Line> getLines() {
        ArrayList<Line> lines = new ArrayList<>();
        for (int i = 0; i < vertices.length; i++) {
            lines.add(new Line(vertices[i], vertices[(i + 1) % vertices.length]));
        }
        return lines;
    }

    @Override
    public Point getCenter() {
        double sumX = 0, sumY = 0;
        for (Point vertex : vertices) {
            sumX += vertex.getX();
            sumY += vertex.getY();
        }
        return new Point(sumX / vertices.length, sumY / vertices.length);
    }

    @Override
    public void rotate(double angle) {
        Point center = getCenter();
        for (Point vertex : vertices) {
            vertex.rotateAbout(center, angle);
        }
    }

    @Override
    public void setCenter(Point newCenter) {
        Point currentCenter = getCenter();
        double dx = newCenter.getX() - currentCenter.getX();
        double dy = newCenter.getY() - currentCenter.getY();
        for (Point vertex : vertices) {
            vertex.setX(vertex.getX() + dx);
            vertex.setY(vertex.getY() + dy);
        }
    }
}
