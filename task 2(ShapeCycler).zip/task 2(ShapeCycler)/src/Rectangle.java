import java.util.ArrayList;

public class Rectangle extends Shape {
    private Point center;
    private double width, height;

    public Rectangle(Point center, double width, double height) {
        this.center = center;
        this.width = width;
        this.height = height;
    }

    public double getWidth() {
        return width;
    }

    public double getHeight() {
        return height;
    }

    public void setWidth(double width) {
        this.width = width;
    }

    public void setHeight(double height) {
        this.height = height;
    }

    @Override
    public ArrayList<Point> getPoints() {
        ArrayList<Point> points = new ArrayList<>();
        double halfWidth = width / 2;
        double halfHeight = height / 2;

        // Calculate corner points relative to the center
        points.add(new Point(center.getX() - halfWidth, center.getY() - halfHeight)); // Bottom-left
        points.add(new Point(center.getX() + halfWidth, center.getY() - halfHeight)); // Bottom-right
        points.add(new Point(center.getX() + halfWidth, center.getY() + halfHeight)); // Top-right
        points.add(new Point(center.getX() - halfWidth, center.getY() + halfHeight)); // Top-left

        return points;
    }

    @Override
    public ArrayList<Line> getLines() {
        ArrayList<Line> lines = new ArrayList<>();
        ArrayList<Point> points = getPoints();

        // Create lines by connecting consecutive points
        for (int i = 0; i < points.size(); i++) {
            lines.add(new Line(points.get(i), points.get((i + 1) % points.size()))); // Ensure it wraps around
        }

        return lines;
    }

    @Override
    public Point getCenter() {
        return center;
    }

    @Override
    public void setCenter(Point newCenter) {
        this.center = newCenter;
    }

    @Override
    public void rotate(double angle) {
        // Rotate each corner point about the center
        ArrayList<Point> points = getPoints();
        for (Point p : points) {
            p.rotateAbout(center, angle);
        }
    }
}
