import java.util.ArrayList;

public abstract class Shape {
    // Abstract method to return points that make up the shape
    public abstract ArrayList<Point> getPoints();
    
    // Abstract method to return lines that make up the shape
    public abstract ArrayList<Line> getLines();
    
    // Abstract method to rotate the shape by a specified angle
    public abstract void rotate(double angle);
    
    // Abstract method to get the center of the shape
    public abstract Point getCenter();
    
    // Abstract method to set a new center for the shape
    public abstract void setCenter(Point newCenter);
}
