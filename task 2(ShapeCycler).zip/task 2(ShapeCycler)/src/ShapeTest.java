import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class ShapeTest {

    public static void main(String[] args) {
        JFrame frame = new JFrame("Shape Drawing");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 400);
        frame.setLocationRelativeTo(null);

        DrawingPad drawingPad = new DrawingPad();
        frame.add(drawingPad);

        frame.setVisible(true);
    }

    static class DrawingPad extends JPanel {
        private int shapeIndex = 0;
        private java.awt.Point lastClickPoint;

        public DrawingPad() {
            setBackground(Color.WHITE);

            addMouseListener(new MouseAdapter() {
                @Override
                public void mousePressed(MouseEvent e) {
                    lastClickPoint = e.getPoint();
                    repaint();
                }
            });
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);

            if (lastClickPoint != null) {
                g.setColor(Color.RED);

                switch (shapeIndex % 3) {
                    case 0:
                        g.fillOval((int) lastClickPoint.getX() - 25, (int) lastClickPoint.getY() - 25, 50, 50);
                        break;
                    case 1:
                        g.fillRect((int) lastClickPoint.getX() - 25, (int) lastClickPoint.getY() - 25, 50, 50);
                        break;
                    case 2:
                        g.drawLine((int) lastClickPoint.getX() - 25, (int) lastClickPoint.getY() - 25, (int) lastClickPoint.getX() + 25, (int) lastClickPoint.getY() + 25);
                        break;
                }

                shapeIndex++;
            }
        }
    }
}
