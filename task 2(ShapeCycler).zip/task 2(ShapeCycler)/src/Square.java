public class Square extends Rectangle {

    // Constructor to initialize a Square with a center and side length
    public Square(Point center, double sideLength) {
        super(center, sideLength, sideLength); // Use Rectangle's constructor with equal width and height
    }

    // Override setWidth to ensure both width and height are updated for a square
    @Override
    public void setWidth(double sideLength) {
        super.setWidth(sideLength);
        super.setHeight(sideLength); // Keep height equal to the width
    }

    // Override setHeight to ensure both height and width are updated for a square
    @Override
    public void setHeight(double sideLength) {
        super.setWidth(sideLength); // Keep width equal to the height
        super.setHeight(sideLength);
    }

    // Ensure square-specific behavior remains consistent
    @Override
    public void rotate(double angle) {
        super.rotate(angle); // Use Rectangle's rotate method as behavior is identical
    }
}
