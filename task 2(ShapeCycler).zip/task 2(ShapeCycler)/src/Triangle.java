// Triangle.java
import java.util.ArrayList;

public class Triangle extends Shape {
    private Point[] points = new Point[3];

    public Triangle(Point p1, Point p2, Point p3) {
        points[0] = p1;
        points[1] = p2;
        points[2] = p3;
    }

    @Override
    public Point getCenter() {
        double centerX = (points[0].getX() + points[1].getX() + points[2].getX()) / 3;
        double centerY = (points[0].getY() + points[1].getY() + points[2].getY()) / 3;
        return new Point(centerX, centerY);
    }

    @Override
    public ArrayList<Point> getPoints() {
        ArrayList<Point> pointList = new ArrayList<>();
        for (Point p : points) {
            pointList.add(p);
        }
        return pointList;
    }

    @Override
    public ArrayList<Line> getLines() {
        ArrayList<Line> lines = new ArrayList<>();
        lines.add(new Line(points[0], points[1]));
        lines.add(new Line(points[1], points[2]));
        lines.add(new Line(points[2], points[0]));
        return lines;
    }

    @Override
    public void rotate(double angle) {
        Point center = getCenter();
        for (Point p : points) {
            p.rotateAbout(center, angle);
        }
    }

    @Override
    public void setCenter(Point newCenter) {
        Point currentCenter = getCenter();
        double dx = newCenter.getX() - currentCenter.getX();
        double dy = newCenter.getY() - currentCenter.getY();
        for (Point p : points) {
            p.setX(p.getX() + dx);
            p.setY(p.getY() + dy);
        }
    }
}
